""" ./main.py """
import os
import sys


def main():
    addon_dir = "/storage/.kodi/addons/service.wireguard.manager"
    lib_path = os.path.join(addon_dir, "resources", "lib")

    if lib_path not in sys.path:
        sys.path.insert(0, lib_path)

    import kodi_env
    main_launcher = __import__("main_launcher")

    try:
        main_launcher.run(sys.argv)
    finally:
        kodi_env.clear_script_globals()


if __name__ == "__main__":
    main()
