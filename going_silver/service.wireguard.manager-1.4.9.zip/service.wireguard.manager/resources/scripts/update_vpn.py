""" ./resources/scripts/update_vpn.py """
import sys
import os
import xbmcaddon
from vpn_config import PROVIDER_MAP
from logger import log_message

script_path = os.path.dirname(__file__)
lib_path = os.path.join(script_path, "..", "lib")
sys.path.append(os.path.normpath(lib_path))

_ADDON_INSTANCE = None


def get_addon_instance():
    global _ADDON_INSTANCE
    if _ADDON_INSTANCE is None:
        _ADDON_INSTANCE = xbmcaddon.Addon("service.wireguard.manager")
    return _ADDON_INSTANCE


def main():
    addon_obj = get_addon_instance()
    provider_idx = addon_obj.getSettingInt("vpn_provider")
    config_dir = "/storage/.config/wireguard/"

    p_data = PROVIDER_MAP.get(provider_idx)
    if not p_data:
        clear_script_globals()
        return

    provider_module = p_data["module"]

    try:
        if provider_idx == 0:
            token = addon_obj.getSetting("vpn_token")
            countries = addon_obj.getSetting("selected_countries")
            provider_module.update(token, countries, config_dir)

        elif provider_idx == 1:
            user = addon_obj.getSetting("pia_user")
            pw = addon_obj.getSetting("pia_pass")
            countries = addon_obj.getSetting("selected_countries")
            provider_module.update(user, pw, countries, config_dir)

        elif provider_idx == 2:
            account = addon_obj.getSetting("mullvad_account")
            countries = addon_obj.getSetting("mullvad_filter")
            mtu = addon_obj.getSettingInt("mullvad_mtu")
            provider_module.generate_mullvad_configs(account, countries, mtu)
            provider_module.convert_to_connman_configs()

        elif provider_idx == 99:
            path = addon_obj.getSetting("custom_path")
            provider_module.update(path, config_dir)

    except Exception as e:
        log_message(f"Script Error: {e}", 3)
    finally:
        clear_script_globals()


def clear_script_globals():
    global _ADDON_INSTANCE
    _ADDON_INSTANCE = None
    import gc
    gc.collect()


if __name__ == "__main__":
    main()
