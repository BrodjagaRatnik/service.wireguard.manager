""" ./resources/lib/vpn_connector.py """
import os
import re
import subprocess
import time
from logger import log_message
from vpn_config import (
    DHCP_RECOVERY_DELAY,
    PROVIDER_MAP,
    ROUTE_PROP_DELAY,
    VPN_CONNECTION_TIMEOUT,
)
from network_utils import (
    set_secure_dns,
    get_default_gateway,
    disable_connman_ipv6,
    resolve_server_ip
)
from vpn_utils import (
    flush_connman_dns_cache,
    is_interface_active,
    fetch_vpn_metadata,
    setup_pia_handshake
)
from state_manager import get_file_path

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    HAS_KODI = True
except ImportError:
    HAS_KODI = False

ADDON_ID = 'service.wireguard.manager'

if HAS_KODI is True:
    _ADDON = xbmcaddon.Addon(ADDON_ID)
    ADDON_PATH = _ADDON.getAddonInfo('path')
else:
    _ADDON = None
    ADDON_PATH = '/storage/.kodi/addons/service.wireguard.manager'

ICON_CON = os.path.join(ADDON_PATH, 'resources', 'media', 'vpn_connected.png')
ICON_ERROR = os.path.join(ADDON_PATH, 'resources', 'media', 'error.png')
ICON_INFO = os.path.join(ADDON_PATH, 'resources', 'media', 'icon.png')


def connect_vpn(vpn_name, sid, instance, silent=False):
    lock_path = get_file_path('connector_lock')
    if lock_path is not None:
        try:
            with open(lock_path, "w") as f:
                f.write(str(os.getpid()))
                f.flush()
                os.fsync(f.fileno())
        except Exception:
            pass
    provider_id = _ADDON.getSettingInt("vpn_provider") if (HAS_KODI and _ADDON) else 0
    p_data = PROVIDER_MAP.get(provider_id, {})
    p_name = p_data.get("name", "").lower()
    if p_name == "pia":
        log_message("VPN Connector: PIA route detected. Triggering API handshake...", 0)
        if setup_pia_handshake(sid, p_data, _ADDON, HAS_KODI) is False:
            if lock_path is not None and os.path.exists(lock_path) is True:
                try:
                    os.remove(lock_path)
                except Exception:
                    pass
            return False
    log_message(f"VPN Connector: Connecting to {vpn_name}", 0)

    pbg = None
    if silent is False and HAS_KODI is True:
        pbg = xbmcgui.DialogProgressBG()
        pbg.create("VPN Manager", f"Connecting to {vpn_name}...")
    subprocess.run(["connmanctl", "connect", sid], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    connected = False
    max_steps = int(VPN_CONNECTION_TIMEOUT / DHCP_RECOVERY_DELAY)
    step_percent = 100.0 / max_steps
    for i in range(1, max_steps + 1):
        if pbg and HAS_KODI:
            pbg.update(int(i * step_percent), message=f"Verifying... ({int((i * DHCP_RECOVERY_DELAY) / 1000)}s)")
        if is_interface_active("wg0") is True:
            connected = True
            break
        if HAS_KODI is True:
            xbmc.sleep(DHCP_RECOVERY_DELAY)
        else:
            time.sleep(DHCP_RECOVERY_DELAY / 1000.0)
    if pbg and HAS_KODI:
        pbg.close()
    if connected is True:
        log_message(f"VPN Connector: Successfully connected to {vpn_name}", 1)
        if p_data.get("requires_endpoint_route") is True:
            try:
                server_ip = resolve_server_ip(sid)
                if not server_ip:
                    from network_utils import CONFIG_DIR
                    config_file = os.path.join(CONFIG_DIR, f"{sid}.config")
                    if os.path.exists(config_file):
                        with open(config_file, "r") as f:
                            for line in f:
                                if "host" in line.lower() and "=" in line:
                                    raw_host = line.split("=")[-1].strip()
                                    ip_match = re.search(
                                        r'([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})',
                                        raw_host
                                    )
                                    if ip_match:
                                        server_ip = ip_match.group(1)
                                        break
                if server_ip:
                    gw_out = subprocess.check_output(["ip", "route", "show", "default"], text=True)
                    local_gw = get_default_gateway()
                    local_dev = None
                    for line in gw_out.splitlines():
                        if "dev" in line and "wg0" not in line:
                            parts = line.split("dev")[-1].strip().split()
                            if parts:
                                local_dev = parts
                                break
                    if local_gw is not None and local_dev is not None:
                        subprocess.run(
                            ["route", "add", "-host", server_ip, "gw", local_gw, "dev", local_dev],
                            check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                        )
            except Exception:
                pass
            try:
                subprocess.run(
                    ["route", "del", "default", "netmask", "128.0.0.0", "dev", "wg0"],
                    check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
                subprocess.run(
                    ["route", "add", "-net", "0.0.0.0", "netmask", "128.0.0.0", "dev", "wg0"],
                    check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
                subprocess.run(
                    ["route", "add", "-net", "128.0.0.0", "netmask", "128.0.0.0", "dev", "wg0"],
                    check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
            except Exception:
                pass
        else:
            try:
                subprocess.run(
                    ["ip", "route", "add", "default", "dev", "wg0", "metric", "0"],
                    check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
            except Exception:
                pass
        subprocess.run(["ip", "route", "flush", "cache"], check=False)
        instance.set_active_vpn(vpn_name)
        set_secure_dns(vpn_name, vpn_active=True)
        if HAS_KODI is True:
            xbmc.sleep(ROUTE_PROP_DELAY)
        else:
            time.sleep(ROUTE_PROP_DELAY / 1000.0)
        try:
            disable_connman_ipv6()
        except Exception:
            pass
        if HAS_KODI is True:
            ip, country = fetch_vpn_metadata()
            if not ip or ip == "Unknown":
                title = "[B][COLOR FFFF0000]▄■ [ CONNECTION FAILED ] ■▄[/COLOR][/B]"
                msg = f" [B]═≡═ [COLOR FFFFFF00]{vpn_name}[/COLOR] ═≡═[/B]\n[B]No routing / Tunnel offline[/B]"
                xbmcgui.Dialog().notification(title, msg, xbmcgui.NOTIFICATION_ERROR, 5000)
            elif silent is True:
                title = "[B][COLOR FF00FFFF]▄■ [ SYSTEM RESTARTED ] ■▄[/COLOR][/B]"
                msg = (
                    f" [B]═≡═ [COLOR FFFFFF00]Tunnel Restored[/COLOR] ═≡═[/B]\n"
                    f"[B]Profile [COLOR FF32CD32]{vpn_name}[/COLOR] • ({country})[/B]"
                )
                xbmcgui.Dialog().notification(title, msg, ICON_CON, 4500)
            else:
                title = "[B][COLOR FF00FF00]▄■ [ CONNECTED ] ■▄[/COLOR][/B]"
                msg = (
                    f" [B]═≡═ [COLOR FF32CD32]{vpn_name}[/COLOR] ═≡═[/B]\n"
                    f"[B]IP [COLOR FFFFFF00]{ip}[/COLOR] • "
                    f"[COLOR FFFF8C00]({country})[/COLOR][/B]"
                )
                xbmcgui.Dialog().notification(title, msg, ICON_CON, 4500)

        if lock_path is not None and os.path.exists(lock_path) is True:
            try:
                os.remove(lock_path)
            except Exception:
                pass
        return True
    err_msg = "Handshake failed. Refused, rate-limited, or unreachable." if get_default_gateway() else "Internet lost."
    log_message(f"VPN Connector: VPN connection, handshake failed. {err_msg}", 3)
    if silent is False and HAS_KODI is True:
        xbmcgui.Dialog().notification("[B][COLOR ffff0000]▀■▄ VPN FAILURE ▄■▀[/COLOR][/B]", err_msg, ICON_ERROR, 5000)
    subprocess.run(["connmanctl", "disconnect", sid], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    instance.disconnect_vpn(silent=True, flush_dns=False)
    flush_connman_dns_cache()
    if lock_path is not None and os.path.exists(lock_path) is True:
        try:
            os.remove(lock_path)
        except Exception:
            pass
    return False
