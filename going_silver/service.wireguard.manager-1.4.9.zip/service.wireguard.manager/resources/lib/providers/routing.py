""" ./resources/lib/providers/routing.py
routing.get_allowed_ips() Result: "0.0.0.0/0
routing.get_allowed_ips(use_split_default=True) Result: "0.0.0.0/1, 128.0.0.0/1"
"""
import os
import subprocess
from logger import log_message


def get_allowed_ips(
    lan_bypass: bool = False,
    custom_bypass_subnets: list = None,
    use_split_default: bool = False,
    provider_requires_split: bool = False
) -> str:
    if use_split_default is True or provider_requires_split is True:
        return "0.0.0.0/1, 128.0.0.0/1"
    return "0.0.0.0/0"


def get_optimal_mtu() -> str:
    chosen_mtu = "1380"
    try:
        from vpn_utils import get_active_interface
        target_iface = get_active_interface()

        if not target_iface:
            out_route = subprocess.check_output(["ip", "route", "show", "default"], text=True)
            for line in out_route.splitlines():
                if "dev" in line:
                    parts = line.split()
                    idx = parts.index("dev")
                    if idx + 1 < len(parts):
                        target_iface = parts[idx + 1]
                        break

        if target_iface and (os.path.exists(f"/sys/class/net/{target_iface}/mtu") is True):
            with open(f"/sys/class/net/{target_iface}/mtu", "r") as f:
                phys_mtu = int(f.read().strip())

            calculated_wg_mtu = phys_mtu - 80
            if calculated_wg_mtu >= 1420:
                chosen_mtu = "1420"
            elif calculated_wg_mtu >= 1400:
                chosen_mtu = "1400"
            elif calculated_wg_mtu >= 1380:
                chosen_mtu = "1380"
            else:
                chosen_mtu = "1280"
    except Exception as mtu_err:
        log_message(f"Routing: Kernel MTU calculation failure: {mtu_err}", 2)

    return chosen_mtu
