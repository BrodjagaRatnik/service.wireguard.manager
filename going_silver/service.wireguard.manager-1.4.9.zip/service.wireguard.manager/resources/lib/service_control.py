""" ./resources/lib/service_control.py """
import os
import subprocess
import sys
from logger import log_message
from vpn_config import PROVIDER_MAP, SYSTEMD_POLL_DELAY
from state_manager import get_file_path

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
    KODI_MODE = True
except ImportError as e:
    KODI_MODE = False
    sys.stderr.write(f"CONTROL CRITICAL: Kodi environment missing or failed initialization: {e}\n")
    sys.stderr.flush()

_ADDON_INSTANCE = None


def get_addon_instance():
    global _ADDON_INSTANCE
    if KODI_MODE is True and _ADDON_INSTANCE is None:
        _ADDON_INSTANCE = xbmcaddon.Addon('service.wireguard.manager')
    return _ADDON_INSTANCE


def get_addon_dir():
    if KODI_MODE is True:
        addon_obj = get_addon_instance()
        if addon_obj:
            return xbmcvfs.translatePath(addon_obj.getAddonInfo('path'))
    return '/storage/.kodi/addons/service.wireguard.manager'


ADDON_DIR = get_addon_dir()
LIB_PATH = os.path.join(ADDON_DIR, 'resources', 'lib')

if LIB_PATH not in sys.path:
    sys.path.append(LIB_PATH)


def control_service():
    service_name = "vpn-watchdog.service"
    raw_args = "|".join(sys.argv).lower()

    addon_path = get_addon_dir()
    media_path = os.path.join(addon_path, 'resources', 'media')
    icon_ok = os.path.join(media_path, 'update_ok.png')
    icon_err = os.path.join(media_path, 'error.png')

    if "restart" in raw_args:
        action = "restart"
    elif "clear" in raw_args:
        action = "clear"
    else:
        action = "status"

    try:
        if action == "restart":
            log_message("Service Control: Restarting watchdog service...", 0)
            subprocess.run(["systemctl", "restart", service_name], check=True)
            if KODI_MODE is True:
                title = "[B][COLOR FFBF00FF]≡ [ WATCHDOG ] ≡[/COLOR][/B]"
                msg = "[COLOR FFFFFF00]Service Restarted[/COLOR]"
                xbmcgui.Dialog().notification(title, msg, icon_ok, 3000)

        elif action == "status":
            if not os.path.exists(f'/storage/.config/system.d/{service_name}'):
                real_status = "Not Installed"
            else:
                real_status = "unknown"
                for i in range(1, 6):
                    result = subprocess.run(["systemctl", "is-active", service_name], capture_output=True, text=True)
                    real_status = result.stdout.strip()
                    if real_status == "active":
                        break
                    if KODI_MODE is True:
                        xbmc.sleep(SYSTEMD_POLL_DELAY)

                if real_status == "activating":
                    real_status = "Initializing..."

            log_message(f"Service Control: Watchdog service {real_status}", 0)
            if KODI_MODE is True:
                icon_path = os.path.join(addon_path, 'resources', 'media', 'icon.png')
                title = "[B][COLOR FFBF00FF]≡ [ WATCHDOG ] ≡[/COLOR][/B]"
                msg = f"[COLOR FFFFFF00]Status: [/COLOR][COLOR FFE6E6FA]{real_status}[/COLOR]"
                xbmcgui.Dialog().notification(title, msg, icon_path, 3000)

        elif action == "clear":
            if KODI_MODE is True and (not xbmcgui.Dialog().yesno("Confirm Reset", "Delete all VPN configurations?")):
                clear_control_globals()
                return

            log_message("Service Control: Clearing configs and disconnecting VPN...", 0)

            p_names = "|".join([p['name'] for p in PROVIDER_MAP.values()])

            disconnect_cmd = (
                f"connmanctl services | grep -E '{p_names}|vpn_wireguard' | "
                "awk '{{print $NF}}' | xargs -I {{}} connmanctl disconnect {{}}"
            )
            subprocess.run(disconnect_cmd, shell=True)
            subprocess.run("rm -f /storage/.config/wireguard/*.config", shell=True)

            keys_to_remove = ['active', 'disconnect', 'manual', 'reconnect']

            for key in keys_to_remove:
                f = get_file_path(key)
                if f is not None and (os.path.exists(f) is True):
                    try:
                        os.remove(f)
                    except Exception as e:
                        log_message(f"Service Control: Cleanup failure for {f}: {e}", 3)

            subprocess.run(["systemctl", "restart", "connman-vpn"])

            if KODI_MODE is True:
                title = "[B][COLOR FFBF00FF]≡ [ WG MANAGER ] ≡[/COLOR][/B]"
                message = "[COLOR FFFFFF00]All configs cleared[/COLOR]"
                xbmcgui.Dialog().notification(title, message, icon_ok, 4000)
                xbmc.executebuiltin('Container.Refresh')

    except Exception as e:
        log_message(f"Service Control: ({action}): {e}", 3)
        if KODI_MODE is True:
            title = "[B][COLOR FFBF00FF]≡ ERROR ≡[/COLOR][/B]"
            message = f"[COLOR FFFFFF00]{action.capitalize()} failed[/COLOR]"
            xbmcgui.Dialog().notification(title, message, icon_err, 5000)
    finally:
        clear_control_globals()


def clear_control_globals():
    global _ADDON_INSTANCE
    _ADDON_INSTANCE = None
    import gc
    gc.collect()


if __name__ == "__main__":
    control_service()
