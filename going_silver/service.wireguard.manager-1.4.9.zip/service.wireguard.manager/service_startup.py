""" ./service_startup.py """
import os
import sys


def main():
    addon_dir = "/storage/.kodi/addons/service.wireguard.manager"
    lib_path = os.path.join(addon_dir, "resources", "lib")

    if lib_path not in sys.path:
        sys.path.insert(0, lib_path)

    import kodi_env
    service_launcher = __import__("service_launcher")

    try:
        service_launcher.start()
    finally:
        kodi_env.clear_script_globals()


if __name__ == "__main__":
    main()
