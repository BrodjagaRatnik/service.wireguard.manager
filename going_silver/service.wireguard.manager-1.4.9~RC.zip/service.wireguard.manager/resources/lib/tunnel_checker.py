""" ./resources/lib/tunnel_checker.py """
import kodi_env
import os
import subprocess
import time

try:
    import xbmcgui
    HAS_GUI = True
except ImportError:
    HAS_GUI = False

from logger import log_message
from vpn_utils import is_interface_active, get_active_interface
from state_manager import get_active_vpn


def run_tunnel_sanity_check():
    if not is_interface_active("wg0"):
        return

    addon_obj = kodi_env.get_addon_instance()
    if not addon_obj:
        kodi_env.clear_script_globals()
        return

    addon_path = kodi_env.ADDON_DIR
    icon_con = os.path.join(addon_path, "resources", "media", "vpn_connected.png")

    try:
        current_default_iface = get_active_interface()
        tunnel_is_broken = False

        if current_default_iface != "wg0":
            tunnel_is_broken = True
        else:
            try:
                res = subprocess.run(
                    ["ping", "-c", "1", "-W", "2", "1.1.1.1"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=False,
                    timeout=3.0
                )
                if res.returncode != 0:
                    log_message("Tunnel Check: Interface up but end-to-end routing ping failed.", 2)
                    tunnel_is_broken = True
            except subprocess.TimeoutExpired:
                log_message("Tunnel Check: Process execution timed out.", 2)
                tunnel_is_broken = True
            except Exception as ping_err:
                log_message(f"Tunnel Check: Connection verification exception: {ping_err}", 3)
                tunnel_is_broken = True

        if tunnel_is_broken:
            log_message("Tunnel Check: Dead link confirmed. Forcing reconnect sequence...", 2)

            boot_target = get_active_vpn()

            import vpn_ops
            vpn_ops.disconnect_vpn(silent=True, flush_dns=True)
            time.sleep(1.5)

            if boot_target:
                from service_launcher import resolve_service_id
                sid = resolve_service_id(addon_obj, boot_target.replace(" ", "_"))
                if not sid:
                    sid = resolve_service_id(addon_obj, boot_target)

                if sid:
                    log_message(f"Tunnel Check: Re-establishing profile link [{boot_target}] safely.", 1)
                    vpn_ops.connect_vpn(str(boot_target), str(sid), silent=True)

                    if HAS_GUI:
                        title = "[B][COLOR FF00FF00]▄■ [ TUNNEL RESTORED ] ■▄[/COLOR][/B]"
                        msg = f"[COLOR FFE6E6FA]Reconnected to {boot_target}[/COLOR]"
                        xbmcgui.Dialog().notification(title, msg, icon_con, 4500)
                else:
                    log_message(f"Tunnel Check: Service ID lookup dropped for {boot_target}", 3)
            else:
                log_message("Tunnel Check: No active link cached in configuration text. Recovery dropped.", 2)
        else:
            log_message("Tunnel Check: Link health verification successfully. Tunnel is clear.", 1)

    except Exception as e:
        log_message(f"Tunnel Check: Monitoring framework tracking exception: {e}", 3)
    finally:
        kodi_env.clear_script_globals()


if __name__ == "__main__":
    run_tunnel_sanity_check()
