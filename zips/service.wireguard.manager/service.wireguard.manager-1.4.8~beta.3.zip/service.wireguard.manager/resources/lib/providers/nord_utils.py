""" ./resources/lib/providers/nord_utils.py """
import os
import sys
import json
import ssl
import urllib.error
import urllib.request
import xbmcaddon
import xbmcvfs
from logger import log_message

_ADDON = xbmcaddon.Addon('service.wireguard.manager')
_LIB = xbmcvfs.translatePath(os.path.join(_ADDON.getAddonInfo('path'), 'resources', 'lib'))
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)


def fetch_nord_url(url, post_data=None):
    """Network fetcher optimized for NordVPN's massive unified JSON payloads."""
    headers = {
        'User-Agent': 'service.wireguard.manager/1.0',
        'Accept': 'application/json'
    }

    try:
        data_bytes = None
        if post_data is not None:
            data_bytes = json.dumps(post_data).encode('utf-8')
            headers['Content-Type'] = 'application/json'

        req = urllib.request.Request(url, data=data_bytes, headers=headers)
        log_message(f"Nord Utils: Sending request to: {url}", 0)

        try:
            req_ctx = ssl.create_default_context()
        except Exception:
            req_ctx = ssl._create_unverified_context()

        with urllib.request.urlopen(req, timeout=30, context=req_ctx) as response:
            raw_body = response.read().decode('utf-8').strip()
            if raw_body:
                return json.loads(raw_body)

    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        log_message(f"Nord Utils: HTTP ERROR: {e.code} on {url}. Body: {error_body}", 3)
        try:
            return json.loads(error_body)
        except Exception:
            return None
    except Exception as e:
        log_message(f"Nord Utils: UNKNOWN ERROR on {url}: {e}", 3)
        return None
