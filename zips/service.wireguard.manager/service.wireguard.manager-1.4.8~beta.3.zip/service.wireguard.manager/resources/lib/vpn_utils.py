''' ./resources/lib/vpn_utils.py '''
import os
import json
import socket
import subprocess
from logger import log_message

try:
    import xbmcaddon
    import xbmcvfs
    HAS_KODI = True
except ImportError:
    HAS_KODI = False

ADDON_ID = 'service.wireguard.manager'

if HAS_KODI:
    try:
        ADDON_PATH = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('path'))
    except Exception:
        ADDON_PATH = '/storage/.kodi/addons/service.wireguard.manager'
else:
    ADDON_PATH = '/storage/.kodi/addons/service.wireguard.manager'

ICON_INFO = os.path.join(ADDON_PATH, 'resources', 'media', 'icon.png')
ICON_ERROR = os.path.join(ADDON_PATH, 'resources', 'media', 'error.png')


def is_interface_active(interface_name="wg0"):
    return os.path.exists(f"/sys/class/net/{interface_name}")


def verify_tunnel_routing(test_ip="1.1.1.1", timeout=1.5):
    try:
        socket.setdefaulttimeout(timeout)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((test_ip, 53))
        return True
    except Exception:
        return False


def fetch_vpn_metadata():
    try:
        res = subprocess.check_output(
            ["curl", "-s", "-k", "--connect-timeout", "1.0", "--max-time", "1.5", "https://1.1.1.1/cdn-cgi/trace"],
            text=True
        )
        ip = "Unknown"
        country = "??"
        for line in res.splitlines():
            if line.startswith("ip="):
                ip = line.split("=")[1].strip()
            if line.startswith("loc="):
                country = line.split("=")[1].strip()
        if ip != "Unknown":
            return ip, country
    except Exception:
        pass

    try:
        res = subprocess.check_output(
            ["curl", "-s", "--connect-timeout", "1.0", "--max-time", "5", "https://ipinfo.io"],
            text=True
        )
        data = json.loads(res)
        if "ip" in data:
            return data.get("ip", "Unknown"), data.get("country", "??")
    except Exception:
        pass

    try:
        res = subprocess.check_output(
            ["curl", "-s", "--connect-timeout", "1.0", "--max-time", "1.5", "https://geojs.io"],
            text=True
        )
        data = json.loads(res)
        if "ip" in data:
            return data.get("ip", "Unknown"), data.get("country", "??")
    except Exception as e:
        log_message(f"VPN_Utils: All metadata fallbacks failed: {e}", 2)

    return None, None


def setup_pia_handshake(sid, provider_data, addon_obj, has_kodi):
    from resources.lib.providers.pia_utils import setup_pia_handshake as resolve_pia_handshake
    return resolve_pia_handshake(sid, provider_data, addon_obj, has_kodi)
