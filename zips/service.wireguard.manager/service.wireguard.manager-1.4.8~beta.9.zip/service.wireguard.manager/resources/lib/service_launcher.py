''' ./resources/lib/service_launcher.py '''
import os
import sys
import time
import xbmc
import xbmcaddon
import xbmcvfs
from logger import log_message
from vpn_config import PI5, WATCHDOG_HEARTBEAT
import vpn_ops
from service_updater import handle_settings_update
from service_resolver import resolve_service_id
from service_loop import execute_monitor_loop
from vpn_core import check_for_updates

try:
    from setup_helper import ensure_setup
except ImportError:
    from setup_utils import ensure_setup

ADDON_DIR = '/storage/.kodi/addons/service.wireguard.manager'
LIB_PATH = os.path.join(ADDON_DIR, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.append(LIB_PATH)


class WGManagerService(xbmc.Monitor):

    def __init__(self, addon, vpn_ops_mod):
        super().__init__()
        self._ADDON = addon
        self.vpn_ops = vpn_ops_mod
        self.cleanup_count = 0
        self.last_bg_check_time = time.time()

        hardware = "Raspberry Pi 5" if PI5 else "Raspberry Pi 4"
        log_message(f"Service Launcher: Hardware timings loaded for {hardware}", 1)
        log_message("Service Launcher: Monitor Service Initialized & Ready", 1)

    def onSettingsChanged(self):
        handle_settings_update(self._ADDON)

        try:
            from vpn_utils import encrypt_setting_to_base64
            encrypt_setting_to_base64('pia_pass')
        except ImportError:
            try:
                from wm_utils import encrypt_setting_to_base64
                encrypt_setting_to_base64('pia_pass')
            except Exception as e:
                log_message(f"Service Launcher: Settings encryption helper unavailable: {e}", 2)

    def get_service_id_by_name(self, name):
        return resolve_service_id(self._ADDON, name)

    def run_loop(self):
        execute_monitor_loop(self)

        current_time = time.time()
        if (current_time - self.last_bg_check_time) >= 60:
            self.last_bg_check_time = current_time
            try:
                addon_path = xbmcvfs.translatePath(
                    self._ADDON.getAddonInfo('path')
                )
                media_path = os.path.join(addon_path, 'resources', 'media')
                check_for_updates(media_path)
            except Exception as e:
                log_message(f"Service Launcher: Background update verification failure: {e}", 3)


def start():
    addon = xbmcaddon.Addon('service.wireguard.manager')
    path = xbmcvfs.translatePath(addon.getAddonInfo('path'))

    if not addon.getSettingBool("first_run"):
        if ensure_setup(path, silent=True) is True:
            addon.setSettingBool("first_run", True)
            xbmc.executebuiltin('Container.Refresh')

    try:
        monitor = WGManagerService(addon, vpn_ops)
    except Exception as e:
        log_message(f"Service Launcher: Monitor failed to start: {e}", 3)
        return

    try:
        is_enabled = addon.getSetting('disconnect_on_start').lower() == 'true'
        log_msg = f"Service Launcher: Verified configuration [Enabled: {is_enabled}]"
        log_message(log_msg, 0)

        if is_enabled:
            pre_active = monitor.vpn_ops.get_active_vpn()

            for f in ['/tmp/vpn_manager_active.txt', '/tmp/vpn_reconnect_count.txt']:
                if os.path.exists(f):
                    try:
                        os.remove(f)
                    except Exception as e:
                        log_message(f"Service Launcher: Cleanup error removing {f}: {e}", 3)

            with open('/tmp/vpn_intentional_disconnect.txt', 'w') as f:
                f.write('startup_clean')

            if pre_active:
                log_msg = (
                    "Service Launcher: Startup Cleaner Actively disconnecting "
                    f"live tunnel profile: {pre_active}"
                )
                log_message(log_msg, 1)
                monitor.vpn_ops.disconnect_vpn(silent=True, flush_dns=True)
            else:
                log_msg = (
                    "Service Launcher: Startup Cleaner verified system environment is "
                    "already clean. (No active tunnel connection found)"
                )
                log_message(log_msg, 0)

    except Exception as e:
        log_message(f"Service Launcher: Startup Cleaner Error: {e}", 3)

    try:
        hb = WATCHDOG_HEARTBEAT / 1000.0
    except Exception as e:
        log_message(f"Service Launcher: Watchdog interval calculation failure: {e}", 3)
        hb = 1.0

    while not monitor.abortRequested():
        monitor.run_loop()
        if monitor.waitForAbort(hb):
            break


if __name__ == '__main__':
    start()
