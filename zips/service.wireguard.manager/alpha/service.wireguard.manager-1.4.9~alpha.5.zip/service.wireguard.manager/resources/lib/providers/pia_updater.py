""" ./resources/lib/providers/pia_updater.py
https://github.com/pia-foss/manual-connections/

SERVER_LIST_URL = "https://serverlist.piaservers.net/vpninfo/servers/v6"
"""
import json
import os
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from logger import log_message
from state_manager import get_file_path
from resources.lib.providers import routing

SERVER_LIST_URL = "https://serverlist.piaservers.net/vpninfo/servers/v6"


def update(user, password, country_ids, config_dir):
    selected_list = [i.strip().lower() for i in country_ids.split(',') if i.strip()]

    if os.path.exists(config_dir) is True:
        for filename in os.listdir(config_dir):
            if filename.startswith("pia_") and filename.endswith(".config"):
                file_id = filename.replace("pia_", "").replace(".config", "")
                if file_id not in selected_list:
                    try:
                        os.remove(os.path.join(config_dir, filename))
                    except Exception as r_err:
                        log_message(f"PIA: Server array tracking error skipped {r_err}", 3)

    raw_data = None
    for attempt in range(2):
        try:
            ctx = ssl._create_unverified_context()
            req = urllib.request.Request(SERVER_LIST_URL, headers={'User-Agent': 'PIA-VPN/3.5.0 (Linux)'})

            with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
                raw_data = resp.read().decode('utf-8').strip()
                if "\n" in raw_data:
                    raw_data = raw_data.splitlines()[0].strip()
            break
        except urllib.error.URLError as url_err:
            if "101" in str(url_err) or "unreachable" in str(url_err).lower():
                if attempt == 0:
                    time.sleep(3.0)
                    continue
            log_message(f"PIA: Update Error {url_err}", 3)
            return False
        except Exception as fetch_err:
            log_message(f"PIA: Update Error {fetch_err}", 3)
            return False

    if raw_data is None:
        return False

    try:
        data = json.loads(raw_data)
        name_mapping = {}
        compiled_files_count = 0
        total_nodes_count = 0

        for rid in selected_list:
            server_ips = []
            server_cns = []
            region_name = rid

            for r in data.get('regions', []):
                if r['id'].lower() == rid:
                    servers_dict = r.get('servers', {})
                    if isinstance(servers_dict, dict):
                        wg_servers = servers_dict.get('wg', [])

                        if wg_servers and isinstance(wg_servers, list):
                            for srv in wg_servers:
                                if isinstance(srv, dict) and srv.get('ip') and srv.get('cn'):
                                    server_ips.append(str(srv.get('ip')))
                                    server_cns.append(str(srv.get('cn')))

                    region_name = str(r.get('name', rid))
                    break

            if server_ips:
                safe_key = f"PIA_{region_name.replace(' ', '_')}".lower()
                name_mapping[safe_key] = rid

                v_temp = region_name.replace('Optimized', 'Optimize')
                clean_region_name = v_temp.replace('optimized', 'Optimize')

                os.makedirs(config_dir, exist_ok=True)
                file_path = os.path.join(config_dir, f"pia_{rid}.config")
                with open(file_path, 'w') as f:
                    f.write("[provider_wireguard]\nType = WireGuard\n")
                    f.write(f"Name = PIA_{clean_region_name.replace(' ', '_')}\n")
                    f.write(f"Host = {server_ips[0]}\n")
                    f.write(f"WireGuard.Pool = {','.join(server_ips)}\n")
                    f.write(f"WireGuard.CN_Pool = {','.join(server_cns)}\n")
                    f.write("WireGuard.MTU = 1380\n")
                    f.write("WireGuard.PublicKey = placeholder\n")
                    f.write("WireGuard.Address = 10.0.0.1/32\n")

                compiled_files_count += 1
                total_nodes_count += len(server_ips)

        if compiled_files_count > 0:
            log_message(f"PIA: Batch complete. Compiled {compiled_files_count} regions ({total_nodes_count} nodes).", 0)

        map_path = get_file_path('pia_map')
        if map_path is not None:
            try:
                with open(map_path, 'w') as mf:
                    json.dump(name_mapping, mf)
            except Exception:
                pass

        return True

    except Exception as e:
        log_message(f"PIA Update Error: {e}", 3)
        return False


def build_final_config(wg_data, pk, server_ip, region_id, region_name=None, raw_cn_str="", allowed_ips_mode=1):
    dns_str = "10.0.0.243, 10.0.0.241, 1.1.1.1, 9.9.9.9"
    if not region_name:
        region_name = region_id
    safe_name = region_name.replace(' ', '_')
    port_str = str(wg_data.get('server_port', '1337'))

    allowed_ips = routing.get_allowed_ips()

    return (
        "[provider_wireguard]\n"
        "Type = WireGuard\n"
        f"Name = PIA_{safe_name}\n"
        f"Host = {server_ip}\n"
        "WireGuard.MTU = 1380\n"
        f"WireGuard.Address = {wg_data['peer_ip']}/32\n"
        f"WireGuard.PrivateKey = {pk}\n"
        f"WireGuard.PublicKey = {wg_data['server_key']}\n"
        f"WireGuard.DNS = {dns_str}\n"
        f"WireGuard.EndpointPort = {port_str}\n"
        f"WireGuard.AllowedIPs = {allowed_ips}\n"
        "WireGuard.PersistentKeepalive = 25\n"
        f"WireGuard.CN_Pool = {raw_cn_str}\n"
    )
