""" ./resources/lib/service_matcher.py """
import os
import json
from state_manager import get_file_path


def is_nord_match(vpn_target, active_now):
    if vpn_target is None:
        return False
    if not vpn_target:
        return False
    if active_now is None:
        return False
    if not active_now:
        return False

    v_clean = str(vpn_target).strip().lower().replace("_", "").replace("-", "").replace(" ", "")
    a_raw = str(active_now).strip().lower()

    parts = a_raw.split()
    if not parts:
        return False

    if len(parts) == 1:
        a_name = a_raw.replace(".config", "").replace(".conf", "")
    else:
        service_id = parts[-1]
        if service_id.startswith("vpn_"):
            a_name = a_raw[:a_raw.rfind(service_id)].strip()
        else:
            a_name = a_raw.replace(service_id, "").strip()

    for flag in ["*", "R", "A", "O", "d"]:
        if a_name.startswith(flag + " "):
            a_name = a_name[2:].strip()

    a_clean = a_name.strip().lower().replace("_", "").replace("-", "").replace(" ", "")

    v_nord = v_clean.replace("nordvpn", "").replace("nord", "")
    a_nord = a_clean.replace("nordvpn", "").replace("nord", "")

    if v_nord == a_nord:
        return True

    return False


def is_pia_match(vpn_target, active_now):
    if vpn_target is None:
        return False
    if not vpn_target:
        return False
    if active_now is None:
        return False
    if not active_now:
        return False

    v_clean = str(vpn_target).strip().lower()
    a_clean = str(active_now).strip().lower()

    if v_clean == a_clean:
        return True
    if v_clean in a_clean:
        return True
    if a_clean in v_clean:
        return True

    v_alphanumeric = "".join(c for c in v_clean if c.isalnum())
    a_alphanumeric = "".join(c for c in a_clean if c.isalnum())

    if "optimize" in v_alphanumeric or "optimize" in a_alphanumeric:
        v_base = v_alphanumeric.replace("optimized", "").replace("optimize", "")
        a_base = a_alphanumeric.replace("optimized", "").replace("optimize", "")
        if v_base and a_base and (v_base in a_base or a_base in v_base):
            return True

    map_path = get_file_path('pia_map')
    if map_path is not None and (os.path.exists(map_path) is True):
        try:
            with open(map_path, "r") as f:
                name_map = json.load(f)

            v_lookup_key = v_clean.replace(' ', '_')
            mapped_value = name_map.get(v_lookup_key)
            if mapped_value is not None:
                m_clean = str(mapped_value).strip().lower()
                if m_clean == a_clean or m_clean in a_clean or a_clean in m_clean:
                    return True

            for key, val in name_map.items():
                k_norm = "".join(c for c in str(key).lower() if c.isalnum())
                val_norm = "".join(c for c in str(val).lower() if c.isalnum())

                if v_alphanumeric in k_norm or k_norm in v_alphanumeric:
                    if val_norm in a_alphanumeric or a_alphanumeric in val_norm:
                        return True
                    if "so" in val_norm and ("optimize" in a_alphanumeric or "so" in a_alphanumeric):
                        return True
        except Exception:
            pass

    return False


def is_custom_match(vpn_target, active_now):
    if vpn_target is None:
        return False
    if not vpn_target:
        return False
    if active_now is None:
        return False
    if not active_now:
        return False

    v_clean = str(vpn_target).strip().lower().replace("_", "").replace("-", "").replace(" ", "")
    a_raw = str(active_now).strip()

    parts = a_raw.split()
    if not parts:
        return False

    if len(parts) == 1:
        a_name = a_raw.replace(".config", "").replace(".conf", "")
    else:
        service_id = parts[-1]
        if service_id.startswith("vpn_"):
            a_name = a_raw[:a_raw.rfind(service_id)].strip()
        else:
            a_name = a_raw.replace(service_id, "").strip()

    for flag in ["*", "R", "A", "O", "d"]:
        if a_name.startswith(flag + " "):
            a_name = a_name[2:].strip()

    a_clean = a_name.strip().lower().replace("_", "").replace("-", "").replace(" ", "")

    v_cust = v_clean.replace("custom", "")
    a_cust = a_clean.replace("custom", "")

    if v_cust == a_cust:
        return True

    return False
