""" ./resources/lib/state_manager.py """
import os
from logger import log_message

try:
    import xbmcaddon
    import xbmcvfs
    HAS_KODI_ENV = True
except ImportError:
    HAS_KODI_ENV = False

if HAS_KODI_ENV is True:
    _ADDON = xbmcaddon.Addon('service.wireguard.manager')
    PROFILE_DIR = xbmcvfs.translatePath(_ADDON.getAddonInfo('profile'))
else:
    PROFILE_DIR = '/storage/.kodi/userdata/addon_data/service.wireguard.manager'

FILE_MAP = {
    'active': 'vpn_manager_active.txt',
    'manual': 'vpn_manual_active.txt',
    'reconnect': 'vpn_reconnect_count.txt',
    'disconnect': 'vpn_intentional_disconnect.txt',
    'blackout': 'vpn_blackout_active.lock',
    'pia_map': 'pia_name_map.json',
    'pia_cache': 'pia_token_cache.json',
    'connector_lock': 'vpn_connector_active.lock',
    'notif_lock': 'vpn_notif_sent.lock'
}


def get_file_path(key):
    if key not in FILE_MAP:
        return None
    if not os.path.exists(PROFILE_DIR):
        try:
            os.makedirs(PROFILE_DIR)
        except Exception as e:
            log_message(f"State Manager: Failed to create profile path: {e}", 3)
    return os.path.join(PROFILE_DIR, FILE_MAP[key])


def clear_startup_states():
    startup_keys = ['active', 'reconnect']
    for key in startup_keys:
        path = get_file_path(key)
        if path is not None and (os.path.exists(path) is True):
            try:
                os.remove(path)
            except Exception as e:
                log_message(f"State Manager: Cleanup error removing {path}: {e}", 3)


def write_state(key, content):
    path = get_file_path(key)
    if path is None:
        return False
    try:
        with open(path, 'w') as f:
            f.write(str(content))
        return True
    except Exception as e:
        log_message(f"State Manager: Writing failure for key {key}: {e}", 3)
        return False


def read_state(key):
    path = get_file_path(key)
    if path is None or (os.path.exists(path) is False):
        return None
    try:
        with open(path, 'r') as f:
            return f.read().strip()
    except Exception as e:
        log_message(f"State Manager: Reading failure for key {key}: {e}", 3)
        return None


def get_active_vpn():
    path = get_file_path('active')
    if path is not None and (os.path.exists(path) is True):
        try:
            with open(path, "r") as f:
                return f.read().strip() or None
        except Exception as e:
            log_message(f"State Manager: Active VPN state read error: {e}", 3)
            return None
    return None


def get_reboot_vpn():
    if not os.path.exists('/sys/class/net/wg0'):
        return None
    path = get_file_path('active')
    if path is not None and (os.path.exists(path) is True):
        try:
            with open(path, "r") as f:
                return f.read().strip() or None
        except Exception as e:
            log_message(f"State Manager: Reboot state validation error: {e}", 3)
            return None
    return None


def set_active_vpn(name):
    path = get_file_path('active')
    if path is None:
        return
    try:
        if name:
            with open(path, "w") as f:
                f.write(name.strip())
        elif os.path.exists(path) is True:
            os.remove(path)
    except Exception as e:
        log_message(f"State Manager: State Error {e}", 3)
