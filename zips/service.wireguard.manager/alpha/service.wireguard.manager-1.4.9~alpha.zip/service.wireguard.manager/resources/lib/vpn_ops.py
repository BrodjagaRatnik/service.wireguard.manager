""" ./resources/lib/vpn_ops.py """
import os
import subprocess
import time
from logger import log_message
from vpn_config import (
    DHCP_RECOVERY_DELAY,
    OS_RELEASE_DELAY,
    PROP_SYNC_DELAY,
    PROVIDER_MAP,
)
from network_utils import (
    set_secure_dns,
    enable_connman_ipv6,
    get_default_gateway,
)
from vpn_utils import flush_connman_dns_cache
from state_manager import get_file_path, set_active_vpn

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    HAS_KODI = True
except ImportError:
    HAS_KODI = False

ADDON_ID = 'service.wireguard.manager'

if HAS_KODI is True:
    _ADDON = xbmcaddon.Addon(ADDON_ID)
    ADDON_PATH = _ADDON.getAddonInfo('path')
else:
    _ADDON = None
    ADDON_PATH = '/storage/.kodi/addons/service.wireguard.manager'

ICON_CON = os.path.join(ADDON_PATH, 'resources', 'media', 'vpn_connected.png')
ICON_DIS = os.path.join(ADDON_PATH, 'resources', 'media', 'vpn_disconnected.png')
ICON_ERROR = os.path.join(ADDON_PATH, 'resources', 'media', 'error.png')
ICON_ERROR_NETWORK = os.path.join(ADDON_PATH, 'resources', 'media', 'router-network-error-alert.png')
ICON_INFO = os.path.join(ADDON_PATH, 'resources', 'media', 'icon.png')
SOUND = os.path.join(ADDON_PATH, 'resources', 'media', 'error.wav')


def disconnect_vpn(silent=False, flush_dns=True):
    if silent is False and HAS_KODI is True:
        xbmcgui.Window(10000).setProperty('vpn_manual_session', '')

    paths_to_clean = []
    manual_path = get_file_path('manual')
    if manual_path is not None:
        paths_to_clean.append(manual_path)

    for path in paths_to_clean:
        if os.path.exists(path) is True:
            try:
                os.remove(path)
            except Exception as e:
                log_message(f"VPN Ops: Disconnect error removing {path}: {e}", 3)

    intentional_path = get_file_path('disconnect')
    if intentional_path is not None:
        try:
            open(intentional_path, 'w').close()
        except Exception as e:
            log_message(f"VPN Ops: Disconnect error creating intentional flag file: {e}", 3)

    if HAS_KODI is True:
        xbmcgui.Window(10000).setProperty('vpn_intentional_disconnect', 'true')
        xbmcgui.Window(10000).setProperty('vpn_manual_session', '')
        xbmc.sleep(PROP_SYNC_DELAY)
    else:
        time.sleep(PROP_SYNC_DELAY / 1000.0)

    try:
        out = subprocess.check_output(["connmanctl", "services"], text=True)
        p_names = "|".join([p['name'] for p in PROVIDER_MAP.values()])

        for line in out.splitlines():
            if (("vpn_" in line or any(p in line for p in p_names.split('|')))
                    and ("* " in line or "R " in line)):
                subprocess.run(
                    ["connmanctl", "disconnect", line.split()[-1]],
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )

    except Exception as e:
        log_message(f"VPN Ops: Disconnect Error {e}", 3)

    if flush_dns is True:
        flush_connman_dns_cache()

    enable_connman_ipv6()
    set_secure_dns(vpn_active=False)
    set_active_vpn(None)

    if silent is False and HAS_KODI is True:
        title = "[B][COLOR FFDF00FF]▄■ [ VPN Network ] ■▄[/COLOR][/B]"
        msg = "[B]╠══ [COLOR FFDF00FF][ DISCONNECTED ][/COLOR] ══╣[/B]"
        xbmcgui.Dialog().notification(title, msg, ICON_DIS, 4500)

    if HAS_KODI is True:
        xbmc.sleep(OS_RELEASE_DELAY)
    else:
        time.sleep(OS_RELEASE_DELAY / 1000.0)

    gw = get_default_gateway()
    if not gw:
        log_message("VPN Ops: Default route lost. Attempting restoration...", 0)
        try:
            out = subprocess.check_output(["connmanctl", "services"], text=True)
            phys_service = next(
                (
                    line.split()[-1] for line in out.splitlines()
                    if line.startswith(('*', 'R')) and "vpn_" not in line
                ),
                None
            )

            if phys_service:
                subprocess.run(["connmanctl", "config", phys_service, "--ipv4", "dhcp"], check=False)
                log_message(f"Operation: DHCP Recovery ({DHCP_RECOVERY_DELAY}ms)", 0)
                if HAS_KODI is True:
                    xbmc.sleep(DHCP_RECOVERY_DELAY)
                else:
                    time.sleep(DHCP_RECOVERY_DELAY / 1000.0)
                gw = get_default_gateway()
        except Exception as e:
            log_message(f"VPN Ops: Route restoration failure: {e}", 3)

    if gw:
        try:
            out_route = subprocess.check_output(["ip", "route", "show", "default"], text=True)
            route_is_missing = "default" not in out_route
            serv = subprocess.check_output(["connmanctl", "services"], text=True)
            target_dev = "eth0" if "ethernet" in serv else "wlan0"
            subprocess.run(["ip", "route", "replace", "default", "via", gw, "dev", target_dev], check=False)
            if route_is_missing is True:
                log_message(f"VPN Ops: Route restored via {gw} on {target_dev}", 0)
        except Exception as e:
            log_message(f"VPN Ops: Route Restore Error {e}", 3)

    if HAS_KODI is True:
        xbmcgui.Window(10000).setProperty('vpn_intentional_disconnect', '')

    if intentional_path is not None and os.path.exists(intentional_path) is True:
        try:
            os.remove(intentional_path)
        except Exception as e:
            log_message(f"VPN Ops: Error removing intentional disconnect file: {e}", 3)


def connect_vpn(vpn_name, sid, silent=False):
    if not HAS_KODI:
        try:
            log_message(f"VPN Ops: Daemon-driven shell link connect sequence initiated for {vpn_name}", 1)
            res = subprocess.run(["connmanctl", "connect", str(sid)], check=False, capture_output=True, text=True)
            if res.returncode == 0 or "Already connected" in res.stderr or "Already connected" in res.stdout:
                set_active_vpn(vpn_name)
                return True
            log_message(f"VPN Ops: Shell connection failure stdout: {res.stdout} stderr: {res.stderr}", 3)
            return False
        except Exception as shell_err:
            log_message(f"VPN Ops: Daemon fallback connector critical exception: {shell_err}", 3)
            return False

    import vpn_connector
    import sys
    instance = sys.modules[__name__]
    return vpn_connector.connect_vpn(vpn_name, sid, instance, silent=silent)
