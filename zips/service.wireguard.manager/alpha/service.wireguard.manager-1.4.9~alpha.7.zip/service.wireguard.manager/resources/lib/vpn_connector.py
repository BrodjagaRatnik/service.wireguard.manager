""" ./resources/lib/vpn_connector.py """
import os
import subprocess
import time
from logger import log_message
from vpn_config import (
    DHCP_RECOVERY_DELAY,
    PROVIDER_MAP,
    ROUTE_PROP_DELAY,
    VPN_CONNECTION_TIMEOUT,
)
from network_utils import (
    set_secure_dns,
    disable_connman_ipv6,
    get_default_gateway
)
from vpn_utils import (
    flush_connman_dns_cache,
    is_interface_active,
    fetch_vpn_metadata,
    setup_pia_handshake
)
from state_manager import get_file_path

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    HAS_KODI = True
except ImportError:
    HAS_KODI = False

ADDON_ID = 'service.wireguard.manager'

if HAS_KODI is True:
    _ADDON = xbmcaddon.Addon(ADDON_ID)
    ADDON_PATH = _ADDON.getAddonInfo('path')
else:
    _ADDON = None
    ADDON_PATH = '/storage/.kodi/addons/service.wireguard.manager'

ICON_CON = os.path.join(ADDON_PATH, 'resources', 'media', 'vpn_connected.png')
ICON_ERROR = os.path.join(ADDON_PATH, 'resources', 'media', 'error.png')
ICON_INFO = os.path.join(ADDON_PATH, 'resources', 'media', 'icon.png')


def connect_vpn(vpn_name, sid, instance, silent=False):
    lock_path = get_file_path('connector_lock')
    if lock_path is not None:
        try:
            with open(lock_path, "w") as f:
                f.write(str(os.getpid()))
                f.flush()
                os.fsync(f.fileno())
        except Exception:
            pass

    provider_id = _ADDON.getSettingInt("vpn_provider") if (HAS_KODI and _ADDON) else 0
    p_data = PROVIDER_MAP.get(provider_id, {})
    p_name = p_data.get("name", "").lower()

    if p_name == "pia":
        log_message("VPN Connector: PIA route detected. Triggering API handshake...", 0)
        if setup_pia_handshake(sid, p_data, _ADDON, HAS_KODI) is False:
            if lock_path is not None and os.path.exists(lock_path) is True:
                try:
                    os.remove(lock_path)
                except Exception:
                    pass
            return False

    log_message(f"VPN Connector: Connecting to {vpn_name}", 0)
    disable_connman_ipv6()
    flush_connman_dns_cache()
    pbg = None

    if silent is False and HAS_KODI is True:
        pbg = xbmcgui.DialogProgressBG()
        pbg.create("VPN Manager", f"Connecting to {vpn_name}...")

    subprocess.run(["connmanctl", "connect", sid], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    connected = False
    max_steps = int(VPN_CONNECTION_TIMEOUT / DHCP_RECOVERY_DELAY)
    step_percent = 100.0 / max_steps

    for i in range(1, max_steps + 1):
        if pbg and HAS_KODI:
            pbg.update(int(i * step_percent), message=f"Verifying... ({int((i * DHCP_RECOVERY_DELAY) / 1000)}s)")
        if is_interface_active("wg0") is True:
            connected = True
            break
        if HAS_KODI is True:
            xbmc.sleep(DHCP_RECOVERY_DELAY)
        else:
            time.sleep(DHCP_RECOVERY_DELAY / 1000.0)

    if pbg and HAS_KODI:
        pbg.close()

    if connected is True:
        log_message(f"VPN Connector: Successfully connected to {vpn_name}", 1)

        if p_data.get("requires_endpoint_route") is True:
            try:
                if "vpn_" in sid:
                    p_elements = sid.split('_')
                    server_ip = f"{p_elements[1]}.{p_elements[2]}.{p_elements[3]}.{p_elements[4]}"
                    gw_out = subprocess.check_output(["ip", "route", "show", "default"], text=True)
                    local_gw = "192.168.178.1"
                    for line in gw_out.splitlines():
                        if "via" in line and "wg0" not in line:
                            local_gw = line.split("via")[1].strip().split()[0]
                            break
                    local_dev = "eth0"
                    for line in gw_out.splitlines():
                        if "dev" in line and "wg0" not in line:
                            local_dev = line.split("dev")[1].strip().split()[0]
                            break
                    subprocess.run(
                        ["route", "add", "-host", server_ip, "gw", local_gw, "dev", local_dev],
                        check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                    )
            except Exception:
                pass

        subprocess.run(["ip", "route", "flush", "cache"], check=False)
        instance.set_active_vpn(vpn_name)
        set_secure_dns(vpn_name, vpn_active=True)

        if HAS_KODI is True:
            xbmc.sleep(ROUTE_PROP_DELAY)
        else:
            time.sleep(ROUTE_PROP_DELAY / 1000.0)

        if HAS_KODI is True:
            ip, country = fetch_vpn_metadata()
            if silent is True:
                title = "[B][COLOR FF00FFFF]▄■ [ SYSTEM RESTARTED ] ■▄[/COLOR][/B]"
                if ip and ip != "Unknown":
                    msg = (
                        f" [B]═≡═ [COLOR FFFFFF00]Tunnel Restored"
                        f"[/COLOR] ═≡═[/B]\n[B]Profile "
                        f"[COLOR FF32CD32]{vpn_name}[/COLOR] • ({country})[/B]"
                    )
                else:
                    msg = (
                        f" [B]═≡═ [COLOR FFFFFF00]Tunnel Restored"
                        f"[/COLOR] ═≡═[/B]\n[B]Profile "
                        f"[COLOR FF32CD32]{vpn_name}[/COLOR][/B]"
                    )
            else:
                title = "[B][COLOR FF00FF00]▄■ [ CONNECTED ] ■▄[/COLOR][/B]"
                if ip and ip != "Unknown":
                    msg = (
                        f" [B]═≡═ [COLOR FF32CD32]{vpn_name}[/COLOR] ═≡═[/B]\n"
                        f"[B]IP [COLOR FFFFFF00]{ip}[/COLOR] • [COLOR FFFF8C00]({country})[/COLOR][/B]"
                    )
                else:
                    msg = (
                        f" [B]═≡═ [COLOR FF32CD32]{vpn_name}[/COLOR] ═≡═[/B]\n"
                        f"[B]Tunnel active[/B]"
                    )
            xbmcgui.Dialog().notification(title, msg, ICON_CON, 4500)

        if lock_path is not None and os.path.exists(lock_path) is True:
            try:
                os.remove(lock_path)
            except Exception:
                pass
        return True

    err_msg = (
        "Handshake failed. Refused, rate-limited, or unreachable."
        if get_default_gateway() else "Internet lost."
    )
    log_message(f"VPN Connector: VPN connection, handshake failed. {err_msg}", 3)

    if silent is False and HAS_KODI is True:
        xbmcgui.Dialog().notification("[B][COLOR ffff0000]▀■▄ VPN FAILURE ▄■▀[/COLOR][/B]", err_msg, ICON_ERROR, 5000)

    subprocess.run(["connmanctl", "disconnect", sid], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    flush_connman_dns_cache()
    instance.disconnect_vpn(silent=True, flush_dns=False)

    if lock_path is not None and os.path.exists(lock_path) is True:
        try:
            os.remove(lock_path)
        except Exception:
            pass
    return False
