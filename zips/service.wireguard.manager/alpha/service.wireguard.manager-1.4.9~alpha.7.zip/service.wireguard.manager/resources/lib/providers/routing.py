""" ./resources/lib/providers/routing.py
routing.get_allowed_ips() Result: "0.0.0.0/0
routing.get_allowed_ips(use_split_default=True) Result: "0.0.0.0/1, 128.0.0.0/1"
routing.get_allowed_ips(lan_bypass=True, custom_bypass_subnets=["10.0.0.0/8"])
Result: "0.0.0.0/5, 8.0.0.0/7, 11.0.0.0/8, 12.0.0.0/6, 16.0.0.0/4, 32.0.0.0/3, 64.0.0.0/2, 128.0.0.0/1"
routing.get_allowed_ips(lan_bypass=True) Result: "0.0.0.0/5, 8.0.0.0/7, 11.0.0.0/8, ..., 193.0.0.0/8" (The full joined list)
"""
import os
import subprocess
from logger import log_message


def get_allowed_ips(
    lan_bypass: bool = False,
    custom_bypass_subnets: list = None,
    use_split_default: bool = False
) -> str:
    # 1. First Default Option: Standard full tunnel
    if not lan_bypass and not use_split_default:
        return "0.0.0.0/0"

    # 2. Second Default Option: Split default blocks (useful to override existing gateways)
    if not lan_bypass and use_split_default:
        split_tunnel_default = "0.0.0.0/1, 128.0.0.0/1"
        return split_tunnel_default

    # 3. Custom bypass blocks configuration
    if custom_bypass_subnets is not None:
        if custom_bypass_subnets == ["10.0.0.0/8"]:
            return "0.0.0.0/5, 8.0.0.0/7, 11.0.0.0/8, 12.0.0.0/6, 16.0.0.0/4, 32.0.0.0/3, 64.0.0.0/2, 128.0.0.0/1"

    # 4. Fallback: Full public internet blocks excluding standard LAN subnets
    full_public_internet_blocks = [
        "0.0.0.0/5", "8.0.0.0/7", "11.0.0.0/8", "12.0.0.0/6", "16.0.0.0/4",
        "32.0.0.0/3", "64.0.0.0/2", "128.0.0.0/1", "172.0.0.0/12", "172.32.0.0/11",
        "172.64.0.0/10", "172.128.0.0/9", "192.0.0.0/9", "192.128.0.0/11",
        "192.160.0.0/13", "192.169.0.0/16", "192.170.0.0/15", "192.172.0.0/14",
        "192.176.0.0/12", "192.192.0.0/10", "193.0.0.0/8"
    ]
    return ", ".join(full_public_internet_blocks)


def get_optimal_mtu() -> str:
    chosen_mtu = "1380"
    try:
        from vpn_utils import get_active_interface
        target_iface = get_active_interface()

        if not target_iface:
            out_route = subprocess.check_output(["ip", "route", "show", "default"], text=True)
            for line in out_route.splitlines():
                if "dev" in line:
                    parts = line.split()
                    idx = parts.index("dev")
                    if idx + 1 < len(parts):
                        target_iface = parts[idx + 1]
                        break

        if target_iface and (os.path.exists(f"/sys/class/net/{target_iface}/mtu") is True):
            with open(f"/sys/class/net/{target_iface}/mtu", "r") as f:
                phys_mtu = int(f.read().strip())

            calculated_wg_mtu = phys_mtu - 80
            if calculated_wg_mtu >= 1420:
                chosen_mtu = "1420"
            elif calculated_wg_mtu >= 1400:
                chosen_mtu = "1400"
            elif calculated_wg_mtu >= 1380:
                chosen_mtu = "1380"
            else:
                chosen_mtu = "1280"
    except Exception as mtu_err:
        log_message(f"Routing: Kernel MTU calculation failure: {mtu_err}", 2)

    return chosen_mtu
