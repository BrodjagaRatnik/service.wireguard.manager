''' ./resources/lib/vpn_core.py '''
import os
import sys
if 'utils' in sys.modules and 'service.wireguard.manager' not in str(sys.modules.get('utils')):
    del sys.modules['utils']

import xbmc
import xbmcaddon
import xbmcvfs
import subprocess
import shutil
import xbmcgui
import time
from logger import log_message
from vpn_config import PROVIDER_MAP

_ADDON = xbmcaddon.Addon('service.wireguard.manager')
ADDON_PATH = xbmcvfs.translatePath(_ADDON.getAddonInfo('path'))
LIB_PATH = os.path.join(ADDON_PATH, 'resources', 'lib')
CONFIG_DIR = '/storage/.config/wireguard/'
_LIB = xbmcvfs.translatePath(os.path.join(_ADDON.getAddonInfo('path'), 'resources', 'lib'))

sys.path = [p for p in sys.path if 'script.module.srgssr' not in p]
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

ICON_INFO = os.path.join(ADDON_PATH, 'resources', 'media', 'icon.png')
ICON_UPDATE = os.path.join(ADDON_PATH, 'resources', 'media', 'update.png')
ICON_UPDATE_OK = os.path.join(ADDON_PATH, 'resources', 'media', 'update_ok.png')
LAST_RUN_TIMESTAMP = 0
CONFIG_DIR = '/storage/.config/wireguard'


def install_service(source, dest, name, media_path):
    try:
        dest_dir = os.path.dirname(dest)
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir, exist_ok=True)

        shutil.copy2(source, dest)
        subprocess.run(["systemctl", "daemon-reload"], check=False)
        subprocess.run(["systemctl", "enable", name], check=False)
        subprocess.run(["systemctl", "restart", name], check=False)

        title = "[B][COLOR FFBF00FF]╠══ [ WG Manager ] ══╣[/COLOR][/B]"
        msg = "[B][COLOR FFFFFF00]Watchdog Installed.[/COLOR][/B]"
        xbmcgui.Dialog().notification(title, msg, ICON_UPDATE_OK, 4000)

        return True

    except Exception as e:
        log_message(f"Core: Service Installation failed: {e}", 3)
        return False


def check_for_updates(media_path):
    global LAST_RUN_TIMESTAMP

    try:
        if time.localtime().tm_year < 2026:
            return

        provider_idx = _ADDON.getSettingInt("vpn_provider")
        p_data = PROVIDER_MAP.get(provider_idx)

        if not p_data or not p_data.get("needs_file_check", False):
            return

        provider_name = p_data["name"]
        file_prefix = p_data["prefix"]

        if os.path.exists(CONFIG_DIR):
            files = [
                f for f in os.listdir(CONFIG_DIR)
                if f.startswith(file_prefix) and f.endswith('.config')
            ]

            if not files:
                return

            try:
                slider_val = _ADDON.getSetting('update_interval_days')
                slider_days = int(float(slider_val)) if slider_val else 3
                if slider_days <= 0:
                    slider_days = 3
            except ValueError:
                slider_days = 3

            max_age_seconds = slider_days * 86400
            current_time = int(time.time())

            try:
                last_update_val = _ADDON.getSetting('last_vpn_update_time')
                last_update_time = int(last_update_val) if last_update_val else 0
            except ValueError:
                last_update_time = 0

            first_file_path = os.path.join(CONFIG_DIR, files[0])
            file_age_seconds = current_time - int(os.path.getmtime(first_file_path))

            log_msg = (
                f"Core: current_time={current_time}, "
                f"last_update_time={last_update_time}, "
                f"file_age={file_age_seconds}, "
                f"max_age={max_age_seconds}"
            )
            log_message(log_msg, 0)

            if LAST_RUN_TIMESTAMP != 0 and (current_time - LAST_RUN_TIMESTAMP) >= 60:
                LAST_RUN_TIMESTAMP = 0

            if LAST_RUN_TIMESTAMP != 0:
                return

            if current_time < last_update_time:
                _ADDON.setSetting('last_vpn_update_time', str(current_time))
                return

            if file_age_seconds > max_age_seconds:
                if (current_time - last_update_time) < 120:
                    log_msg = "Core: Run skipped. Update recently attempted but files are unchanged."
                    log_message(log_msg, 0)
                    return

                update_successful = run_update()

                if update_successful:

                    LAST_RUN_TIMESTAMP = current_time

                    title = (
                        f"[B][COLOR FFBF00FF]╠══ [ WG Manager: "
                        f"{provider_name} ] ══╣[/COLOR][/B]"
                    )
                    msg = (
                        f"[B][COLOR FFFFFF00]{provider_name} server list "
                        f"has been successfully updated![/COLOR][/B]"
                    )
                    xbmcgui.Dialog().notification(
                        title, msg, ICON_UPDATE_OK, 3000
                    )

                else:

                    title = (
                        f"[B][COLOR FFFF3333]╠══ [ WG Manager: "
                        f"{provider_name} ] ══╣[/COLOR][/B]"
                    )
                    msg = (
                        f"[B][COLOR FFFFFFFF]Update failed. Using existing "
                        f"server list ({slider_days} Days old).[/COLOR][/B]"
                    )
                    xbmcgui.Dialog().notification(
                        title, msg, ICON_UPDATE, 4500
                    )

                try:
                    new_age = current_time - int(os.path.getmtime(first_file_path))
                    if new_age < 30:
                        _ADDON.setSetting('last_vpn_update_time', str(current_time))
                        log_message("Core: Update successful. File timestamps updated.", 0)
                    else:
                        log_message("Core: Update completed but files on disk did not change.", 0)
                except Exception:
                    pass
            else:
                log_message("Core: Update skipped. Configurations are still fresh.", 0)

    except Exception as e:
        log_message(f"Update VPN configurations check older than... failure: {e}", 3)


def run_update(direct_token=None, force_provider=None):

    if force_provider is not None:
        provider_idx = force_provider
    else:
        provider_idx = _ADDON.getSettingInt("vpn_provider")

    p_data = PROVIDER_MAP.get(provider_idx)

    if not p_data:
        return False

    provider_name = p_data["name"]

    if provider_idx == 1:
        from providers import pia
        provider_module = pia
    else:
        provider_module = p_data["module"]

    success = False

    if provider_idx == 1:
        country_setting = "selected_countries_pia"
    else:
        country_setting = "selected_countries"

    countries = _ADDON.getSetting(country_setting)

    progress = xbmcgui.DialogProgress()
    progress.create("WG Manager", f"Updating {provider_name}...")

    try:
        if provider_idx == 0:
            token = direct_token if direct_token else _ADDON.getSetting("vpn_token")
            token = token.strip().replace('"', '').replace("'", "")

            if not token or len(token) < 10:
                progress.close()
                title = "[B]≡ [ WireGuard Manager ] ≡[/B]"
                msg = "[COLOR FFFFFF00]Invalid Token. Please check settings.[/COLOR]"
                xbmcgui.Dialog().ok(title, msg)
                return False

            progress.update(30, f"Fetching {provider_name} servers...")
            success = provider_module.update(token, countries, CONFIG_DIR)
            if success:
                progress.update(100, "Update complete!")

        elif provider_idx == 1:
            user = ""
            raw_pw = ""

            try:
                files = [f for f in os.listdir(CONFIG_DIR) if f.lower().endswith('.txt')]
                if files:
                    custom_file = os.path.join(CONFIG_DIR, files[0])
                    with open(custom_file, 'r') as f:
                        lines = [line.strip() for line in f.readlines() if line.strip()]
                        if len(lines) >= 2:
                            user = lines[0]
                            raw_pw = lines[1]
                            log_message(f"Core: Direct File Import Success from {files[0]}: {user}", 0)
            except Exception as e:
                log_message(f"Core: File Scan/Read Error: {str(e)}", 3)

            if not user:
                user = _ADDON.getSetting("pia_user").strip()

            if not raw_pw:
                from wm_utils import safe_decrypt_password
                pw = safe_decrypt_password(_ADDON.getSetting("pia_pass"))
            else:
                from wm_utils import safe_decrypt_password
                pw = safe_decrypt_password(raw_pw)

            if direct_token:
                pw = str(direct_token).strip()

            if not user or not pw:
                progress.close()

                missing_items = []
                if not user:
                    missing_items.append("PIA Username")
                if not pw:
                    missing_items.append("PIA Password")

                missing_str = " and ".join(missing_items)
                log_message(f"Core: PIA Configuration Error: Missing {missing_str}.", 3)

                title = "[B]≡ [ CREDENTIALS MISSING ] ≡[/B]"
                msg = (
                    f"[COLOR ffff0000]Your {missing_str} is missing![/COLOR]\n\n"
                    "[COLOR FFFFFF00]Please enter your complete PIA credentials inside the configuration "
                    "menu, click 'OK' to save them, and try connecting again.[/COLOR]"
                )
                xbmcgui.Dialog().ok(title, msg)
                return False

            progress.update(60, f"Registering {provider_name} keys...")
            success = pia.update(user, pw, countries, CONFIG_DIR)
            if success:
                progress.update(100, "Update complete!")

        elif provider_idx == 99:
            path = _ADDON.getSetting("custom_path")
            if not path or not os.path.exists(path):
                progress.close()
                title = "[B]≡ [ WireGuard Manager ] ≡[/B]"
                msg = "[COLOR FFFFFF00]Select a valid .config file.[/COLOR]"
                xbmcgui.Dialog().ok(title, msg)
                return False

            progress.update(90, "Importing Custom Config...")
            success = provider_module.update(path, CONFIG_DIR)
            if success:
                progress.update(100, "Import complete!")

        progress.close()

        if success:
            log_message(f"Core: Success {provider_name} updated successfully.", 1)
            xbmc.executebuiltin('Container.Refresh')
            return True

        title = "[B]≡ [ WireGuard Manager ] ≡[/B]"
        msg = f"[COLOR FFFFFF00]Error. Failed to update {provider_name}.[/COLOR]"
        xbmcgui.Dialog().ok(title, msg)
        return False

    except Exception as e:
        log_message(f"Core: Update exception: {e}", 3)
        progress.close()
        return False
