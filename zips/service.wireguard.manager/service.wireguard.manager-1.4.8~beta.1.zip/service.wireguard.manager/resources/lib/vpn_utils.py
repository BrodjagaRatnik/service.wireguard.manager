''' ./resources/lib/vpn_utils.py '''
import os
import json
import socket
import re
import subprocess
from logger import log_message
from providers import pia
from wm_utils import safe_decrypt_password

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
    HAS_KODI = True
except ImportError:
    HAS_KODI = False

ADDON_ID = 'service.wireguard.manager'

if HAS_KODI:
    try:
        ADDON_PATH = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('path'))
    except Exception:
        ADDON_PATH = '/storage/.kodi/addons/service.wireguard.manager'
else:
    ADDON_PATH = '/storage/.kodi/addons/service.wireguard.manager'

ICON_INFO = os.path.join(ADDON_PATH, 'resources', 'media', 'icon.png')
ICON_ERROR = os.path.join(ADDON_PATH, 'resources', 'media', 'error.png')


def is_interface_active(interface_name="wg0"):
    return os.path.exists(f"/sys/class/net/{interface_name}")


def verify_tunnel_routing(test_ip="1.1.1.1", timeout=1.5):
    try:
        socket.setdefaulttimeout(timeout)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((test_ip, 53))
        return True
    except Exception:
        return False


def fetch_vpn_metadata():
    try:
        res = subprocess.check_output(
            ["curl", "-s", "-k", "--connect-timeout", "1.0", "--max-time", "1.5", "https://1.1.1.1/cdn-cgi/trace"],
            text=True
        )
        ip = "Unknown"
        country = "??"
        for line in res.splitlines():
            if line.startswith("ip="):
                ip = line.split("=")[1].strip()
            if line.startswith("loc="):
                country = line.split("=")[1].strip()
        if ip != "Unknown":
            return ip, country
    except Exception:
        pass

    try:
        res = subprocess.check_output(
            ["curl", "-s", "--connect-timeout", "1.0", "--max-time", "5", "https://ipinfo.io"],
            text=True
        )
        data = json.loads(res)
        if "ip" in data:
            return data.get("ip", "Unknown"), data.get("country", "??")
    except Exception:
        pass

    try:
        res = subprocess.check_output(
            ["curl", "-s", "--connect-timeout", "1.0", "--max-time", "1.5", "https://geojs.io"],
            text=True
        )
        data = json.loads(res)
        if "ip" in data:
            return data.get("ip", "Unknown"), data.get("country", "??")
    except Exception as e:
        log_message(f"VPN_Utils: All metadata fallbacks failed: {e}", 2)

    return None, None


def setup_pia_handshake(sid, provider_data, addon_obj, has_kodi):
    log_message("PIA VPN_Utils: Entering setup_pia_handshake...", 1)

    try:
        user = str(addon_obj.getSetting("pia_user")).strip().lower()
        raw_pw = addon_obj.getSetting("pia_pass")
        pw = safe_decrypt_password(raw_pw)
        config_path = None
        region_id = None
        conf_dir = '/storage/.config/wireguard/'
        target_suffix = sid.replace('vpn_provider_wireguard_pia_', '').replace('vpn_pia_', '')

        pure_ip = target_suffix.replace('vpn_', '').replace('_', '.')

        for filename in os.listdir(conf_dir):
            if filename.startswith("pia_") and filename.endswith(".config"):
                path_check = os.path.join(conf_dir, filename)
                try:
                    with open(path_check, 'r') as cf:
                        file_content = cf.read()
                    f_id = filename.replace('pia_', '').replace('.config', '')
                    if f_id.lower() == target_suffix.lower() or f"Host = {pure_ip}" in file_content:
                        config_path = path_check
                        region_id = f_id
                        break
                except Exception:
                    continue

        if not config_path:
            log_message(f"PIA Utils: No blueprint found for {target_suffix}", 2)
            return True

        log_message(f"PIA Utils: Found config path={config_path}", 1)
        target_ip = ""
        pool_cns = []
        original_name = None

        with open(config_path, 'r') as f:
            content = f.read()
            host_match = re.search(r'^\s*Host\s*=\s*(.*)', content, re.MULTILINE)
            if host_match:
                target_ip = host_match.group(1).strip()

            name_match = re.search(r'^\s*Name\s*=\s*(.*)', content, re.MULTILINE)
            if name_match:
                original_name = name_match.group(1).strip().replace("PIA_", "")

            cn_pool_match = re.search(r'^\s*WireGuard\.CN_Pool\s*=\s*(.*)', content, re.MULTILINE)
            if cn_pool_match:
                pool_cns = [c.strip() for c in cn_pool_match.group(1).split(',') if c.strip()]

        log_message(f"PIA Utils: Parsed IP={target_ip} ID={region_id} CNs={len(pool_cns)}", 1)

        if not target_ip or not pool_cns:
            log_message("PIA VPN_Utils: Error - Missing nodes or Host IP.", 3)
            return False

        live_cfg = None
        log_message("PIA Utils: Requesting single token for pool...", 1)
        active_token = pia.get_cached_token(user, pw)

        if not active_token:
            raise Exception("Global token acquisition failed.")

        raw_cn_str = ",".join(pool_cns)

        for current_cn in pool_cns:
            clean_cn = current_cn.strip().lower()
            log_message(f"PIA Utils: Try CN={clean_cn} IP={target_ip}", 1)

            live_cfg = pia.get_live_config(
                active_token, target_ip, clean_cn, region_id, original_name, raw_cn_str
            )

            if live_cfg and "[provider_wireguard]" in live_cfg:
                break

        if live_cfg and "[provider_wireguard]" in live_cfg:
            log_message("PIA Utils: Handshake OK! Writing live config...", 1)
            with open(config_path, 'w') as f:
                f.write(live_cfg)
                if has_kodi:
                    xbmc.sleep(1500)
            return True
        else:
            raise Exception("Handshake declined by all upstream target API nodes.")

    except Exception as e:
        err_str = str(e)
        log_message(f"PIA Error: {err_str}", 3)

        if "429" in err_str or "Too Many Requests" in err_str:
            title = "[B]≡ [ API RATE LIMIT ] ≡[/B]"
            msg = (
                "[COLOR ffff0000]PIA API Blocked Your Connection Request![/COLOR]\n\n"
                "Your IP address has been temporarily rate-limited due to too many rapid configuration changes.\n\n"
                "[COLOR ffffff00]SOLUTION:[/COLOR] Please wait [B]15 minutes[/B] before starting this video addon again."
            )
            if has_kodi:
                import xbmcgui
                xbmc.executebuiltin("ActivateWindow(home)")
                xbmcgui.Dialog().ok(title, msg)
                log_message("PIA API Blockade Connection Request start", 1)
                xbmc.Monitor().waitForAbort(900)
                log_message("PIA API Blockade Connection Request over.", 1)
                title = "[B][COLOR FFE6E6FA]≡ [ WG MANAGER ] ≡[/COLOR][/B]"
                msg = "[COLOR FFFFFF00]PIA API Blockade over you can connect to PIA again.[/COLOR]"
                xbmcgui.Dialog().notification(title, msg, ICON_INFO, 5000)
        else:
            title = "[B]≡ [ CONNECTION FAILURE ] ≡[/B]"
            msg = (
                "[COLOR ffff0000]VPN Handshake Failed to Establish![/COLOR]\n\n"
                f"System Error: [COLOR fffxff00]{err_str}[/COLOR]\n\n"
                "The manager was unable to reach the PIA authorization nodes."
            )
            if has_kodi:
                import xbmcgui
                xbmc.executebuiltin("ActivateWindow(home)")
                xbmcgui.Dialog().ok(title, msg)
                log_message("PIA Connection Cool Down start", 1)
                xbmc.Monitor().waitForAbort(600)
                log_message("PIA Connection Cool Down over.", 1)
                title = "[B][COLOR FFE6E6FA]≡ [ WG MANAGER ] ≡[/COLOR][/B]"
                msg = "[COLOR FFFFFF00]Network cool down over. Ready to retry connection.[/COLOR]"
                xbmcgui.Dialog().notification(title, msg, ICON_INFO, 5000)

        return False
