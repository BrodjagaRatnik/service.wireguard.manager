""" ./resources/lib/providers/custom.py """
import os
import sys
import subprocess

try:
    import xbmc
    HAS_KODI = True
except ImportError:
    HAS_KODI = False


def update(source_path, config_dir):
    try:
        if not os.path.exists(config_dir):
            os.makedirs(config_dir, exist_ok=True)

        base = os.path.basename(source_path)
        clean_name = base.lower().replace('.config', '').replace('.conf', '').replace('custom_', '').capitalize()
        dest_name = f"custom_{clean_name.lower()}.conf"
        dest_path = os.path.join(config_dir, dest_name)
        display_name = f"Custom_{clean_name}"

        with open(source_path, 'r') as f:
            lines = f.readlines()

        new_lines = []
        for line in lines:
            if not line.strip().startswith('Name =') and not line.strip().startswith('Type ='):
                new_lines.append(line)

        with open(dest_path, 'w') as f:
            f.writelines(new_lines)

        os.chmod(dest_path, 0o600)

        try:
            subprocess.run(
                ["nmcli", "connection", "delete", "id", display_name],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False
            )
            subprocess.run(
                ["nmcli", "connection", "import", "type", "wireguard", "file", dest_path],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False
            )
            subprocess.run(
                ["nmcli", "connection", "modify", display_name,
                 "ipv4.dns-priority", "-100",
                 "ipv6.dns-priority", "-100",
                 "ipv6.method", "disabled",
                 "wireguard.ip4-auto-default-route", "true"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False
            )
        except Exception as nm_err:
            msg_nm = f"Custom Provider: NetworkManager profile registration failed: {nm_err}"
            if HAS_KODI:
                xbmc.log(msg_nm, xbmc.LOGERROR)

        msg = f"Custom Provider: Imported {clean_name} profile database into NetworkManager successfully."
        if HAS_KODI:
            xbmc.log(msg, xbmc.LOGINFO)
        else:
            sys.stdout.write(f"{msg}\n")
            sys.stdout.flush()

        return True

    except Exception as e:
        err_msg = f"Custom Provider Error: {str(e)}"
        if HAS_KODI:
            xbmc.log(err_msg, xbmc.LOGERROR)
        else:
            sys.stderr.write(f"{err_msg}\n")
            sys.stderr.flush()
        return False
