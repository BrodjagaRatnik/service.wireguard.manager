""" ./resources/lib/vpn_utils.py """
import kodi_env
import json
import os
import subprocess
import time
import datetime
from logger import log_message

try:
    import xbmcgui
    HAS_KODI = True
except ImportError:
    HAS_KODI = False


def get_addon_path():
    return kodi_env.ADDON_DIR


def is_interface_active(interface_name="wg0"):
    try:
        with open("/proc/net/dev", "r") as f:
            content = f.read()
            return f"{interface_name}:" in content
    except Exception:
        return False


def get_active_interface():
    for attempt in range(2):
        try:
            out = subprocess.check_output(
                ["ip", "route", "show", "default"],
                text=True,
                stderr=subprocess.DEVNULL
            )
            interfaces = []
            for line in out.splitlines():
                parts = line.split()
                if "dev" in parts:
                    dev_idx = parts.index("dev") + 1
                    if dev_idx < len(parts):
                        interfaces.append(parts[dev_idx])
            for iface in interfaces:
                if "wg" in iface.lower() or "vpn" in iface.lower() or "nord" in iface.lower() or "pia" in iface.lower():
                    return str(iface)
            if interfaces:
                return str(interfaces[0])
        except Exception as e:
            log_message(f"VPN_Utils: Interface lookup error: {e}", 3)
            return None
        if attempt == 0:
            time.sleep(0.15)
    return None


def check_interface_status():
    try:
        if not os.path.exists("/proc/net/dev"):
            return False, False
        with open("/proc/net/dev", "r") as f:
            lines = f.readlines()

        eth = False
        wifi = False
        for line in lines:
            if ":" in line:
                iface = line.split(":")[0].strip()
                if not iface.startswith(("lo", "wg", "wireguard")):
                    if iface.startswith(("eth", "en")):
                        eth = True
                    elif iface.startswith(("wlan", "wl")):
                        wifi = True
        return eth, wifi
    except Exception as e:
        log_message(f"VPN_Utils: Interface status validation check failure: {e}", 3)
        return False, False


def fetch_vpn_metadata():
    t_stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    target_iface = get_active_interface() or "wg0"

    try:
        res = subprocess.check_output(
            [
                "curl", "-s", "-k",
                "--interface", target_iface,
                "--connect-timeout", "4.0",
                "--max-time", "6.0",
                "https://1.1.1"
            ],
            text=True
        )
        ip = "Unknown"
        country = "??"
        for line in res.splitlines():
            if line.startswith("ip="):
                ip = line.split("=")[1].strip()
            if line.startswith("loc="):
                country = line.split("=")[1].strip()
        if ip != "Unknown":
            log_message(f"VPN_Utils: Cloudflare trace provider selected at {t_stamp}", 0)
            return ip, country
    except Exception:
        pass

    try:
        res = subprocess.check_output(
            [
                "curl", "-s", "--interface", target_iface,
                "--connect-timeout", "4.0", "--max-time", "6.0",
                "https://ipinfo.io"
            ],
            text=True
        )
        if res and res.strip():
            data = json.loads(res)
            if "ip" in data:
                log_message(f"VPN_Utils: Ipinfo provider selected at {t_stamp}", 0)
                return data.get("ip", "Unknown"), data.get("country", "??")
    except Exception:
        pass

    try:
        res = subprocess.check_output(
            [
                "curl", "-s", "--interface", target_iface,
                "--connect-timeout", "4.0", "--max-time", "6.0",
                "https://geojs.io"
            ],
            text=True
        )
        if res and res.strip():
            data = json.loads(res)
            if "ip" in data:
                log_message(f"VPN_Utils: Geojs provider selected at {t_stamp}", 0)
                return data.get("ip", "Unknown"), data.get("country_code", "??")
    except Exception as e:
        log_message(f"VPN_Utils: All metadata fallbacks failed at {t_stamp}: {e}", 2)

    if HAS_KODI:
        try:
            title = "[B][COLOR FFFF0000]VPN Connection Error[/COLOR][/B]"
            msg = "[COLOR FFE6E6FA]Data path blocked. Please update configs or choose another region.[/COLOR]"
            xbmcgui.Dialog().ok(title, msg)
        except Exception:
            pass

    return None, None


def setup_pia_handshake(sid, provider_data, addon_obj, has_kodi):
    from providers.pia_utils import setup_pia_handshake as resolve_pia_handshake
    return resolve_pia_handshake(sid, provider_data, addon_obj, has_kodi)
