""" ./resources/lib/service_resolver.py """
import os
import subprocess
import sys
import kodi_env
from logger import log_message

ADDON_DIR = kodi_env.ADDON_DIR
LIB_PATH = os.path.join(ADDON_DIR, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)


def resolve_service_id(addon, name):
    try:
        if not name:
            return None

        provider_id = addon.getSettingInt("vpn_provider")
        conf_dir = os.path.expanduser("~/.config/wireguard/")
        p_prefix = "nord_" if provider_id == 0 else "custom_"

        clean_target = (
            name.lower()
            .replace('nordvpn', '')
            .replace('custom', '')
            .replace('_', '')
            .replace('-', '')
            .replace(' ', '')
            .strip()
        )

        if os.path.exists(conf_dir):
            for filename in os.listdir(conf_dir):
                if filename.startswith(p_prefix) and filename.endswith((".config", ".conf")):
                    profile_id = filename.replace(".conf", "").replace(".config", "")
                    clean_profile = (
                        profile_id.lower()
                        .replace(p_prefix, '')
                        .replace("_", "")
                        .replace("-", "")
                        .replace(" ", "")
                    )

                    if (clean_target == clean_profile
                            or clean_profile in clean_target or clean_target in clean_profile):
                        return profile_id

        out = subprocess.check_output(["nmcli", "-t", "-f", "NAME", "connection", "show"], text=True)
        for line in out.splitlines():
            cleaned_line = (
                line.strip().lower()
                .replace(p_prefix, '')
                .replace("_", "")
                .replace("-", "")
                .replace(" ", "")
            )
            if clean_target in cleaned_line or cleaned_line in clean_target:
                return line.strip()

    except Exception as e:
        log_message(f"Service Resolver: lookup error for {name}: {e}", 3)
        return None
