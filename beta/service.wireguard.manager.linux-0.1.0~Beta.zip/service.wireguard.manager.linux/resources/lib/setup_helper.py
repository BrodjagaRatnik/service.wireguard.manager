""" ./resources/lib/setup_helper.py """
import kodi_env
import os
import shutil
import subprocess
import sys
from logger import log_message
from vpn_config import PROVIDER_MAP

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
    HAS_KODI = True
except ImportError:
    HAS_KODI = False


def _setup_paths():
    try:
        addon_path = kodi_env.ADDON_DIR
        local_lib = os.path.join(addon_path, "resources", "lib")

        if local_lib not in sys.path:
            sys.path.insert(0, local_lib)

    except Exception as e:
        sys.stderr.write(f"Setup Helper: Path setup critical failure: {e}\n")


_setup_paths()


def perform_cleanup(silent=False):
    addon = kodi_env.get_addon_instance()
    wg_config_path = os.path.expanduser("~/.config/wireguard/")
    user_systemd_dir = os.path.expanduser("~/.config/systemd/user/")
    service_file = os.path.join(user_systemd_dir, "vpn-watchdog.service")

    try:
        log_message("Setup Helper: Cleanup Starting factory reset...", 1)

        if os.path.exists(service_file) is True:
            subprocess.run(["systemctl", "--user", "stop", "vpn-watchdog.service"], check=False)
            subprocess.run(["systemctl", "--user", "disable", "vpn-watchdog.service"], check=False)
            os.remove(service_file)
            subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)

        if os.path.exists(wg_config_path) is True:
            for item in os.listdir(wg_config_path):
                if "_" in item and (item.endswith(".config") or item.endswith(".conf")):
                    try:
                        os.remove(os.path.join(wg_config_path, item))
                    except Exception:
                        pass
            log_message("Setup Helper: Cleanup WireGuard configs wiped.", 1)

        if addon:
            addon.setSetting("selected_countries", "")
            addon.setSetting("selected_countries_pia", "")
            addon.setSetting("first_run", "false")

        keymap_file = xbmcvfs.translatePath("special://userdata/keymaps/wireguard_manager_key.xml")
        if os.path.exists(keymap_file) is True:
            os.remove(keymap_file)

        from state_manager import FILE_MAP, get_file_path
        for key in FILE_MAP:
            tf = get_file_path(key)
            if tf is not None and os.path.exists(tf) is True:
                try:
                    os.remove(tf)
                except Exception as e:
                    log_message(f"Setup Helper: Reset error removing {tf}: {e}", 3)

        log_message("Setup Helper: Cleanup Reset complete.", 1)
        if silent is False and HAS_KODI:
            title = "[B[ CLEANUP COMPLETE ][/B]"
            msg = (
                "[COLOR FFFFFF00]Cleanup successful.[/COLOR]\n"
                "All local client configurations and user services are removed from your device. "
                "You can now safely uninstall WireGuard VPN Manager."
            )
            xbmc.executebuiltin("Dialog.Close(all, true)")
            xbmc.sleep(200)
            xbmcgui.Dialog().ok(title, msg)

    except Exception as e:
        log_message(f"Setup Helper: Cleanup Error: {e}", 3)

    finally:
        kodi_env.clear_script_globals()


def ensure_setup(addon_path, silent=False):
    try:
        ADDON = kodi_env.get_addon_instance()

        if not ADDON or not HAS_KODI:
            log_message("Setup Helper: Abstractions missing. Skipping interface orchestration.", 2)
            return

        keymap_dest = xbmcvfs.translatePath("special://userdata/keymaps/wireguard_manager_key.xml")
        keymap_source = os.path.join(addon_path, "resources", "keymaps", "wireguard_manager_key.xml")
        wg_config_path = os.path.expanduser("~/.config/wireguard/")
        user_systemd_dir = os.path.expanduser("~/.config/systemd/user/")
        service_dest = os.path.join(user_systemd_dir, "vpn-watchdog.service")
        service_source = os.path.join(addon_path, "resources", "data", "vpn-watchdog.service.txt")
        cert_source = os.path.join(addon_path, "resources", "data", "ca.rsa.4096.txt")
        cert_dest = os.path.join(addon_path, "resources", "lib", "providers", "ca.rsa.4096.crt")
        setup_updated = False
        progress = xbmcgui.DialogProgress()
        progress.create("WireGuard Manager", "Starting system check...")
        progress.update(25, "Checking Keymaps...")
        if not os.path.exists(keymap_dest):
            try:
                os.makedirs(os.path.dirname(keymap_dest), exist_ok=True)
                shutil.copy2(keymap_source, keymap_dest)
                log_message("Setup Helper: Keymap installed.", 1)
                xbmc.executebuiltin("Action(ReloadKeymaps)")
                log_message("Setup Helper: Keymaps reloaded in Kodi.", 1)
                setup_updated = True
            except Exception as e:
                log_message(f"Setup Helper: Setup Error (Keymap): {e}", 3)

        progress.update(50, "Installing Linux User Watchdog Service...")
        if not os.path.exists(service_dest):
            try:
                os.makedirs(user_systemd_dir, exist_ok=True)

                with open(service_source, "r") as sf:
                    template = sf.read()

                service_script_path = os.path.join(addon_path, "resources", "lib", "service.py")
                formatted_service = template.format(
                    python_exec=sys.executable,
                    service_script=service_script_path
                )

                with open(service_dest, "w") as df:
                    df.write(formatted_service)

                subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
                subprocess.run(["systemctl", "--user", "enable", "vpn-watchdog.service"], check=False)
                subprocess.run(["systemctl", "--user", "start", "vpn-watchdog.service"], check=False)
                log_message("Setup Helper: Watchdog user-space service installed and active.", 1)
                setup_updated = True
            except Exception as e:
                log_message(f"Setup Helper: Setup Error (User Service): {e}", 3)

        progress.update(75, "Deploying PIA provider certificates...")
        if not os.path.exists(cert_dest):
            try:
                os.makedirs(os.path.dirname(cert_dest), exist_ok=True)
                shutil.copy2(cert_source, cert_dest)
                log_message("Setup Helper: Secure verification certificate deployed.", 1)
                setup_updated = True
            except Exception as e:
                log_message(f"Setup Helper: Setup Error (Certificate Copy): {e}", 3)

        progress.update(90, "Verifying VPN credentials...")
        current_p_id = ADDON.getSettingInt("vpn_provider")
        has_creds = False
        if current_p_id == -1:
            log_message("Setup Helper: No VPN provider selected yet. Skipping credential check.", 1)
        else:
            p_data = PROVIDER_MAP.get(current_p_id, {"name": "Unknown", "prefix": "unknown_"})
            token_setting = p_data.get("setting")
            if token_setting:
                has_creds = bool(ADDON.getSetting(token_setting).strip())
            if current_p_id == 99 or not has_creds:
                prefix = p_data["prefix"]
                if os.path.exists(wg_config_path):
                    has_files = any(f.startswith((prefix, "custom_")) for f in os.listdir(wg_config_path))
                    has_creds = has_creds or has_files

        progress.update(100, "Setup Complete.")
        if setup_updated:
            log_message("Setup Helper: All system checks completed successfully.", 0)
        progress.close()

        if setup_updated:
            log_message("Setup Helper: Success! Background tracking engines active.", 1)

            path_fixed = kodi_env.ADDON_DIR
            ICON_INFO = os.path.join(path_fixed, "resources", "media", "icon.png")
            title = "[B][COLOR FFEEFFEE][ SETUP SUCCESS ][/COLOR][/B]"
            message = "[COLOR FFFFFF00]WireGuard manager service is now active in the background.[/COLOR]"
            xbmcgui.Dialog().notification(title, message, ICON_INFO, 6000)

    except Exception as major_err:
        log_message(f"Setup Helper: Orchestration master failure: {major_err}", 3)

    finally:
        kodi_env.clear_script_globals()


if __name__ == "__main__":
    if len(sys.argv) > 1 and "cleanup" in sys.argv:
        perform_cleanup()
