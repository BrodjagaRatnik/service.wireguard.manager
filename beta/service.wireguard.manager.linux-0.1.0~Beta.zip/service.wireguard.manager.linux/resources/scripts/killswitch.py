""" ./resources/scripts/killswitch.py """
import subprocess
from logger import log_message


def get_live_lan_subnet():
    try:
        out = subprocess.check_output(["ip", "route", "show", "default"], text=True, stderr=subprocess.DEVNULL)
        interfaces = []
        for line in out.splitlines():
            parts = line.split()
            if "dev" in parts:
                dev_idx = parts.index("dev") + 1
                if dev_idx < len(parts):
                    interfaces.append(parts[dev_idx])
        if interfaces:
            target_iface = interfaces[0]
            if_out = subprocess.check_output(["ip", "route", "show", "dev", target_iface], text=True)
            for line in if_out.splitlines():
                parts = line.split()
                if parts and not line.startswith("default") and "proto" in parts:
                    return parts[0]
    except Exception:
        pass
    return "192.168.0.0/16"


class ZeroHardcodeKillSwitch:
    def __init__(self, vpn_server_ip):
        self.vpn_server_ip = vpn_server_ip
        self.enabled = False

    def enable(self):
        if self.enabled:
            return
        live_lan = get_live_lan_subnet()
        log_message(f"KillSwitch: Target local subnet detected as {live_lan}", 0)
        commands = [
            "iptables -N LINUX_WG_KILLSWITCH",
            "iptables -A LINUX_WG_KILLSWITCH -o lo -j ACCEPT",
            f"iptables -A LINUX_WG_KILLSWITCH -d {live_lan} -j ACCEPT",
            f"iptables -A LINUX_WG_KILLSWITCH -d {self.vpn_server_ip} -j ACCEPT",
            "iptables -A LINUX_WG_KILLSWITCH -o vpn_+ -j ACCEPT",
            "iptables -A LINUX_WG_KILLSWITCH -o wg+ -j ACCEPT",
            "iptables -A LINUX_WG_KILLSWITCH -p udp --dport 53 -j DROP",
            "iptables -A LINUX_WG_KILLSWITCH -p tcp --dport 53 -j DROP",
            "iptables -A LINUX_WG_KILLSWITCH -m owner ! --gid-owner root -j DROP",
            "iptables -I OUTPUT 1 -j LINUX_WG_KILLSWITCH"
        ]
        for cmd in commands:
            subprocess.run(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.enabled = True
        log_message("KillSwitch: Firewall killswitch successfully engaged.", 0)

    def disable(self, reason="disengaged"):
        if not self.enabled:
            return
        commands = [
            "iptables -D OUTPUT -j LINUX_WG_KILLSWITCH",
            "iptables -F LINUX_WG_KILLSWITCH",
            "iptables -X LINUX_WG_KILLSWITCH"
        ]
        for cmd in commands:
            subprocess.run(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.enabled = False
        if reason == "switch":
            log_message("KillSwitch: Firewall rules temporarily opened for connection cycle.", 1)
        elif reason == "recovery":
            log_message("KillSwitch: Purging firewall rules for emergency tunnel recovery.", 1)
        else:
            log_message("KillSwitch: Firewall killswitch successfully deactivated.", 1)
